import pymysql
from connDB import connection
try:
    # Установка соединения с БД
    connection = connection.__init__() (db_name = "apteka")

    # Создание объекта курсора
    with connection.cursor() as cursor:
        # Расчет зарплаты для каждой должности на год, с учетом премий
        cursor.execute("SELECT positions.name, positions.salary, COUNT(employees.id) AS count "
                       "FROM employees "
                       "JOIN positions ON employees.position_id = positions.id "
                       "GROUP BY positions.id")
        for row in cursor.fetchall():
            position_name = row['name']
            salary_per_day = row['salary'] / 20
            salary_per_year = row['salary'] * row['count']
            bonus_per_quarter = (row['salary'] * 0.15) * 2
            total_salary_per_year = salary_per_year + bonus_per_quarter
            print(f"{position_name}: {total_salary_per_year} рублей в год")

except pymysql.Error as e:
    print(f'Произошла ошибка: {e}')


finally:
 connection.close()