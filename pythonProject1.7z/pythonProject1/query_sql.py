
# Создание таблицы для должностей
create_table_positions = "CREATE TABLE `positions` (id INTEGER PRIMARY KEY AUTO_INCREMENT," \
                     " name TEXT NOT NULL," \
                     " salary REAL NOT NULL," \
                     " employee_id int);"
# Создание таблицы для сотрудников
create_table_employees = "CREATE TABLE `employees` (id INTEGER PRIMARY KEY AUTO_INCREMENT," \
                     " name TEXT NOT NULL," \
                     " position_id INTEGER NOT NULL," \
                     " email varchar(32)," \
                     " password varchar(32)," \
                     " FOREIGN KEY (position_id) REFERENCES positions (id))"

insert_positions = "INSERT INTO  positions  (name, salary, employee_id) VALUES " \
                   "('Менеджер', 100000, 1 )," \
                   "('Фармацевт', 50000, 2 );"\


insert_employees = "INSERT INTO employees (name, position_id, email, password) VALUES" \
              " ('Иван Иванов', 1, 'aa@mai.ru', 'ss'), " \
              "('Петр Петров', 1, 'rr@mai.ru', 'ss')," \
              "('Анна Сидорова', 2, 'ss@mai.ru', 'ss'),"\
              "('Ольга Иванова', 2, 'uu@mai.ru', 'ss');"\

#создание представлений
view_positions ="CREATE VIEW positions_view AS SELECT name, salary FROM positions;"
view_employees = "CREATE VIEW employees_view AS SELECT e.name AS employee_name, p.name AS position_name, p.salary FROM employees e JOIN positions p ON e.position_id = p.id;"

#вызов предстаавлений
call_positions_view = "SELECT * FROM view_positions;"
call_employees_view = "SELECT * FROM view_employees;"
